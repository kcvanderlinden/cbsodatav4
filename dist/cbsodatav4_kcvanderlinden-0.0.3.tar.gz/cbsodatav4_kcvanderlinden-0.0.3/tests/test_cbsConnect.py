# import sys
# sys.path.insert(0, '../src/cbsodatav4_kcvanderlinden/')
# from src.cbsodatav4_kcvanderlinden import cbsodatav4

# import pandas as pd

# Voor nu niet nodig omdat het het voornamelijk een functie is om multithreaded te werken. Testen ervan is ingewikkeld.